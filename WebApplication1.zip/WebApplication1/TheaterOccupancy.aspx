﻿<%@ Page Title="Theater Occupancy"
Language="C#"
MasterPageFile="~/Site.Master"
AutoEventWireup="true"
CodeBehind="TheaterOccupancy.aspx.cs"
Inherits="WebApplication1.TheaterOccupancy" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .occ-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .occ-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .filter-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 28px;
    }

    .filter-row label {
        font-weight: 600;
        font-size: 15px;
        color: #333;
    }

    .filter-row select {
        padding: 8px 14px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        min-width: 220px;
        background: #fff;
        cursor: pointer;
    }

    .occ-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .occ-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .occ-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
    }

    .occ-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .occ-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .occ-grid tr:hover td {
        background-color: #f5f5fb;
    }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="occ-wrapper">
    <h2>Movie Occupancy Report</h2>

    <div class="filter-row">
        <label>Select Movie:</label>
        <asp:DropDownList
            ID="ddlMovie"
            runat="server"
            AutoPostBack="True"
            AppendDataBoundItems="true"
            DataSourceID="SqlMovies"
            DataTextField="TITLE"
            DataValueField="MOVIE_ID">
            <asp:ListItem Text="-- Select a Movie --" Value=""></asp:ListItem>
        </asp:DropDownList>
    </div>

    <asp:SqlDataSource
        ID="SqlMovies"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="SELECT MOVIE_ID, TITLE FROM MOVIE ORDER BY TITLE">
    </asp:SqlDataSource>

    <div class="occ-grid">
        <asp:GridView
            ID="GridView1"
            runat="server"
            AutoGenerateColumns="False"
            DataSourceID="SqlOccupancy"
            BorderWidth="0"
            GridLines="None"
            EmptyDataText="Select a movie above to view occupancy data."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="TITLE"           HeaderText="Movie Title" />
                <asp:BoundField DataField="SHOW_DATE"       HeaderText="Show Date"
                                DataFormatString="{0:dd-MMM-yyyy}" />
                <asp:BoundField DataField="SHOW_TIMES"      HeaderText="Show Time" />
                <asp:BoundField DataField="HALL_CAPACITY"   HeaderText="Total Seats" />
                <asp:BoundField DataField="BOOKED_SEATS"    HeaderText="Booked Seats" />
                <asp:BoundField DataField="AVAILABLE_SEATS" HeaderText="Available Seats" />
                <asp:BoundField DataField="OCCUPANCY_PCT"   HeaderText="Occupancy %" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource
        ID="SqlOccupancy"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="
            SELECT
                M.TITLE,
                S.SHOW_DATE,
                S.SHOW_TIMES,
                H.HALL_CAPACITY,
                COUNT(DISTINCT T.TICKET_ID) AS BOOKED_SEATS,
                H.HALL_CAPACITY - COUNT(DISTINCT T.TICKET_ID) AS AVAILABLE_SEATS,
                ROUND(COUNT(DISTINCT T.TICKET_ID) * 100.0 / NULLIF(H.HALL_CAPACITY, 0), 1) || '%' AS OCCUPANCY_PCT
            FROM SHOW S
            JOIN MOVIE M ON S.MOVIE_ID = M.MOVIE_ID
            JOIN HALL H ON S.HALL_ID = H.HALL_ID
            LEFT JOIN BOOKING B ON B.SHOW_ID = S.SHOW_ID
            LEFT JOIN TICKET T ON T.BOOKING_ID = B.BOOKING_ID
            WHERE (:MOVIE_ID IS NULL OR M.MOVIE_ID = :MOVIE_ID)
            GROUP BY M.TITLE, S.SHOW_DATE, S.SHOW_TIMES, H.HALL_CAPACITY
            ORDER BY S.SHOW_DATE DESC
        ">
        <SelectParameters>
            <asp:ControlParameter
                Name="MOVIE_ID"
                ControlID="ddlMovie"
                PropertyName="SelectedValue"
                Type="Decimal"
                ConvertEmptyStringToNull="True" />
        </SelectParameters>
    </asp:SqlDataSource>
</div>

</asp:Content>
