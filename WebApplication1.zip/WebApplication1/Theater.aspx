﻿<%@ Page Title ="Theater Page" Language="C#" MasterPageFile="~/site.Master" AutoEventWireup="true" CodeBehind="Theater.aspx.cs" Inherits="WebApplication1.Theater" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .page-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .page-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .data-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .data-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .data-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
    }

    .data-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .data-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .data-grid tr:hover td { background-color: #f5f5fb; }

    .insert-form {
        background: #fff;
        border: 1px solid #e8e8e8;
        border-radius: 8px;
        padding: 24px 28px;
        margin-top: 32px;
        max-width: 500px;
    }

    .insert-form .form-title {
        font-size: 17px;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 18px;
    }

    .insert-form .field-label {
        display: block;
        font-weight: 600;
        font-size: 13px;
        color: #555;
        margin-top: 14px;
        margin-bottom: 5px;
    }

    .insert-form input[type=text] {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    .insert-form input[type=text]:focus {
        outline: none;
        border-color: #1a1a2e;
    }

    .btn-action {
        display: inline-block;
        margin-top: 18px;
        margin-right: 8px;
        padding: 9px 20px;
        background-color: #1a1a2e;
        color: #fff !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-action:hover { background-color: #2e2e5e; }

    .btn-cancel {
        display: inline-block;
        margin-top: 18px;
        padding: 9px 20px;
        background-color: #f0f0f0;
        color: #333 !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-cancel:hover { background-color: #e0e0e0; }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="page-wrapper">
    <h2>Theater</h2>

    <div class="data-grid">
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
            DataKeyNames="THEATRE_ID" DataSourceID="SqlDataSource1"
            BorderWidth="0" GridLines="None"
            EmptyDataText="No theaters found."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="THEATRE_ID"        HeaderText="Theater ID"   ReadOnly="True" />
                <asp:BoundField DataField="THEATRE_NAME"      HeaderText="Theater Name" />
                <asp:BoundField DataField="THEATRE_CITY_HALL" HeaderText="City / Hall" />
                <asp:CommandField ShowDeleteButton="True" ShowEditButton="True" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource ID="SqlDataSource1" runat="server"
        ConnectionString="<%$ ConnectionStrings:Theater %>"
        ProviderName="<%$ ConnectionStrings:Theater.ProviderName %>"
        SelectCommand="SELECT * FROM &quot;THEATRE&quot;"
        DeleteCommand="DELETE FROM &quot;THEATRE&quot; WHERE &quot;THEATRE_ID&quot; = :THEATRE_ID"
        InsertCommand="INSERT INTO &quot;THEATRE&quot; (&quot;THEATRE_ID&quot;, &quot;THEATRE_NAME&quot;, &quot;THEATRE_CITY_HALL&quot;) VALUES (:THEATRE_ID, :THEATRE_NAME, :THEATRE_CITY_HALL)"
        UpdateCommand="UPDATE &quot;THEATRE&quot; SET &quot;THEATRE_NAME&quot; = :THEATRE_NAME, &quot;THEATRE_CITY_HALL&quot; = :THEATRE_CITY_HALL WHERE &quot;THEATRE_ID&quot; = :THEATRE_ID">
        <DeleteParameters><asp:Parameter Name="THEATRE_ID" Type="Decimal" /></DeleteParameters>
        <InsertParameters>
            <asp:Parameter Name="THEATRE_ID"        Type="Decimal" />
            <asp:Parameter Name="THEATRE_NAME"      Type="String" />
            <asp:Parameter Name="THEATRE_CITY_HALL" Type="String" />
        </InsertParameters>
        <UpdateParameters>
            <asp:Parameter Name="THEATRE_NAME"      Type="String" />
            <asp:Parameter Name="THEATRE_CITY_HALL" Type="String" />
            <asp:Parameter Name="THEATRE_ID"        Type="Decimal" />
        </UpdateParameters>
    </asp:SqlDataSource>

    <div class="insert-form">
        <div class="form-title">Add New Theater</div>
        <asp:FormView ID="FormView1" runat="server" DataKeyNames="THEATRE_ID"
            DataSourceID="SqlDataSource1" DefaultMode="Insert">
            <InsertItemTemplate>
                <span class="field-label">Theater ID</span>
                <asp:TextBox ID="THEATRE_IDTextBox"        runat="server" Text='<%# Bind("THEATRE_ID") %>' />
                <span class="field-label">Theater Name</span>
                <asp:TextBox ID="THEATRE_NAMETextBox"      runat="server" Text='<%# Bind("THEATRE_NAME") %>' />
                <span class="field-label">City / Hall</span>
                <asp:TextBox ID="THEATRE_CITY_HALLTextBox" runat="server" Text='<%# Bind("THEATRE_CITY_HALL") %>' />
                <br />
                <asp:LinkButton ID="InsertButton"       runat="server" CausesValidation="True"  CommandName="Insert" Text="Insert" CssClass="btn-action" />
                <asp:LinkButton ID="InsertCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </InsertItemTemplate>
            <EditItemTemplate>
                <span class="field-label">Theater Name</span>
                <asp:TextBox ID="THEATRE_NAMETextBox"      runat="server" Text='<%# Bind("THEATRE_NAME") %>' />
                <span class="field-label">City / Hall</span>
                <asp:TextBox ID="THEATRE_CITY_HALLTextBox" runat="server" Text='<%# Bind("THEATRE_CITY_HALL") %>' />
                <br />
                <asp:LinkButton ID="UpdateButton"       runat="server" CausesValidation="True"  CommandName="Update" Text="Update" CssClass="btn-action" />
                <asp:LinkButton ID="UpdateCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </EditItemTemplate>
            <ItemTemplate></ItemTemplate>
        </asp:FormView>
    </div>
</div>

</asp:Content>
