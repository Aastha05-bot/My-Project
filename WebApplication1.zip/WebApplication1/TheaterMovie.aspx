﻿<%@ Page Title="Theater Movie Page"
Language="C#"
MasterPageFile="~/Site.Master"
AutoEventWireup="true"
CodeBehind="TheaterMovie.aspx.cs"
Inherits="WebApplication1.TheaterMovie" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .occ-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .occ-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .filter-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 28px;
    }

    .filter-row label {
        font-weight: 600;
        font-size: 15px;
        color: #333;
    }

    .filter-row select {
        padding: 8px 14px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        min-width: 220px;
        background: #fff;
        cursor: pointer;
    }

    .section-heading {
        font-size: 16px;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 14px;
        padding-bottom: 8px;
        border-bottom: 2px solid #e8e8e8;
    }

    .occ-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .occ-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
        white-space: nowrap;
    }

    .occ-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
        vertical-align: middle;
    }

    .occ-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
        font-weight: 600;
        color: #1a1a2e;
    }

    .occ-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .occ-grid tr:hover td {
        background-color: #f5f5fb;
    }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="occ-wrapper">
    <h2>Theater Movie &amp; Showtimes</h2>

    <div class="filter-row">
        <label>Select Theater:</label>
        <asp:DropDownList
    ID="ddlTheater"
    runat="server"
    AutoPostBack="True"
    DataSourceID="SqlTheaters"
    DataTextField="DISPLAY_NAME"
    DataValueField="THEATRE_ID">
</asp:DropDownList>
    </div>

    <asp:SqlDataSource
        ID="SqlTheaters"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="
            SELECT THEATRE_ID,
                   THEATRE_NAME || ' — ' || THEATRE_CITY_HALL AS DISPLAY_NAME
            FROM THEATRE
            ORDER BY THEATRE_NAME">
    </asp:SqlDataSource>

    <div class="section-heading">All Movies and Showtimes</div>

    <div class="occ-grid">
        <asp:GridView
            ID="GridView1"
            runat="server"
            AutoGenerateColumns="False"
            DataSourceID="SqlMovieShowtimes"
            BorderWidth="0"
            GridLines="None"
            EmptyDataText="Select theater to show all scheduled movie and showtimes."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="TITLE"           HeaderText="Movie Title" />
                <asp:BoundField DataField="SHOW_DATE"       HeaderText="Show Date"
                                DataFormatString="{0:dd-MMM-yyyy}" />
                <asp:BoundField DataField="SHOW_TIMES"      HeaderText="Show Time" />
                <asp:BoundField DataField="HALL_ID"         HeaderText="Hall" />
                <asp:BoundField DataField="HALL_CAPACITY"   HeaderText="Capacity" />
                <asp:BoundField DataField="BOOKED_SEATS"    HeaderText="Booked" />
                <asp:BoundField DataField="AVAILABLE_SEATS" HeaderText="Available" />
                <asp:BoundField DataField="OCCUPANCY_PCT"   HeaderText="Occupancy %" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource
        ID="SqlMovieShowtimes"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="
            SELECT
                M.TITLE,
                S.SHOW_DATE,
                S.SHOW_TIMES,
                H.HALL_ID,
                H.HALL_CAPACITY,
                COUNT(DISTINCT T.TICKET_ID) AS BOOKED_SEATS,
                H.HALL_CAPACITY - COUNT(DISTINCT T.TICKET_ID) AS AVAILABLE_SEATS,
                ROUND(COUNT(DISTINCT T.TICKET_ID) * 100.0
                      / NULLIF(H.HALL_CAPACITY, 0), 1) || '%' AS OCCUPANCY_PCT
            FROM SHOW S
            JOIN MOVIE   M  ON M.MOVIE_ID    = S.MOVIE_ID
            JOIN HALL    H  ON H.HALL_ID     = S.HALL_ID
            JOIN THEATRE TH ON TH.THEATRE_ID = H.THEATRE_ID
            LEFT JOIN BOOKING B ON B.SHOW_ID    = S.SHOW_ID
            LEFT JOIN TICKET  T ON T.BOOKING_ID = B.BOOKING_ID
            WHERE TH.THEATRE_ID = :THEATRE_ID
            GROUP BY M.TITLE, S.SHOW_DATE, S.SHOW_TIMES, H.HALL_ID, H.HALL_CAPACITY
            ORDER BY M.TITLE, S.SHOW_DATE DESC, S.SHOW_TIMES">
        <SelectParameters>
            <asp:ControlParameter
                Name="THEATRE_ID"
                ControlID="ddlTheater"
                PropertyName="SelectedValue"
                Type="Decimal"
                ConvertEmptyStringToNull="True" />
        </SelectParameters>
    </asp:SqlDataSource>

</div>

</asp:Content>
