﻿
Copy

using System;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string conn = ConfigurationManager.ConnectionStrings["Ticket"].ConnectionString;

                using (OracleConnection con = new OracleConnection(conn))
                {
                    con.Open();

                    // Stat cards
                    lblMovies.Text = GetScalar(con, "SELECT COUNT(*) FROM MOVIE");
                    lblTheaters.Text = GetScalar(con, "SELECT COUNT(*) FROM THEATRE");
                    lblShowtimes.Text = GetScalar(con, "SELECT COUNT(*) FROM SHOW");
                    lblTickets.Text = GetScalar(con, "SELECT COUNT(*) FROM TICKET");

                    // Pie chart — showtimes by session
                    string pieSql = @"
                        SELECT SHOW_TIMES, COUNT(*) AS TOTAL
                        FROM SHOW
                        GROUP BY SHOW_TIMES
                        ORDER BY SHOW_TIMES";

                    DataTable pieDt = GetTable(con, pieSql);
                    var pL = new System.Text.StringBuilder();
                    var pD = new System.Text.StringBuilder();
                    foreach (DataRow row in pieDt.Rows)
                    {
                        if (pL.Length > 0) { pL.Append("|"); pD.Append("|"); }
                        pL.Append(row["SHOW_TIMES"]);
                        pD.Append(row["TOTAL"]);
                    }
                    hfPieLabels.Value = pL.ToString();
                    hfPieData.Value = pD.ToString();
                }
            }
        }

        private string GetScalar(OracleConnection con, string sql)
        {
            using (OracleCommand cmd = new OracleCommand(sql, con))
            {
                object r = cmd.ExecuteScalar();
                return r != null ? r.ToString() : "0";
            }
        }

        private DataTable GetTable(OracleConnection con, string sql)
        {
            using (OracleCommand cmd = new OracleCommand(sql, con))
            using (OracleDataAdapter da = new OracleDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}