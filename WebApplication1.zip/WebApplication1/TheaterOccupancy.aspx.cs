﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class TheaterOccupancy : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlMovie.Items.Clear();
            }
        }
    }
}