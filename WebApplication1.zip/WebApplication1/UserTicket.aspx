﻿<%@ Page Title="User Ticket"
Language="C#"
MasterPageFile="~/Site.Master"
AutoEventWireup="true"
CodeBehind="UserTicket.aspx.cs"
Inherits="WebApplication1.UserTicket" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .ticket-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .ticket-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .filter-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 28px;
    }

    .filter-row label {
        font-weight: 600;
        font-size: 15px;
        color: #333;
    }

    .filter-row select {
        padding: 8px 14px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        min-width: 200px;
        background: #fff;
        cursor: pointer;
    }

    .ticket-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .ticket-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .ticket-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
    }

    .ticket-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .ticket-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .ticket-grid tr:hover td {
        background-color: #f5f5fb;
    }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="ticket-wrapper">
    <h2>User Ticket History (6 Months)</h2>

    <div class="filter-row">
        <label>Select User:</label>
        <asp:DropDownList
            ID="ddlUser"
            runat="server"
            AutoPostBack="True"
            AppendDataBoundItems="true"
            DataSourceID="SqlUsers"
            DataTextField="USERNAME"
            DataValueField="USER_ID">
            <asp:ListItem Text="-- Select User --" Value=""></asp:ListItem>
        </asp:DropDownList>
    </div>

    <asp:SqlDataSource
        ID="SqlUsers"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="SELECT USER_ID, USERNAME FROM USERS ORDER BY USERNAME">
    </asp:SqlDataSource>

    <div class="ticket-grid">
        <asp:GridView
            ID="GridView1"
            runat="server"
            AutoGenerateColumns="False"
            DataSourceID="SqlTicketHistory"
            BorderWidth="0"
            GridLines="None"
            EmptyDataText="No ticket history found."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="USERNAME"      HeaderText="User Name" />
                <asp:BoundField DataField="EMAIL"         HeaderText="Email" />
                <asp:BoundField DataField="TICKET_ID"     HeaderText="Ticket ID" />
                <asp:BoundField DataField="TICKET_PRICE"  HeaderText="Ticket Price" />
                <asp:BoundField DataField="PAYMENT_STATUS" HeaderText="Payment Status" />
                <asp:BoundField DataField="BOOKING_DATE"  HeaderText="Booking Date"
                                DataFormatString="{0:dd-MMM-yyyy}" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource
        ID="SqlTicketHistory"
        runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="
            SELECT
                U.USERNAME,
                U.EMAIL,
                T.TICKET_ID,
                T.TICKET_PRICE,
                T.PAYMENT_STATUS,
                B.BOOKING_DATE
            FROM USERS U
            JOIN BOOKING B ON U.USER_ID = B.USER_ID
            JOIN TICKET T ON B.BOOKING_ID = T.BOOKING_ID
            WHERE (:USER_ID IS NULL OR U.USER_ID = :USER_ID)
            AND B.BOOKING_DATE >= ADD_MONTHS(SYSDATE, -6)
            ORDER BY B.BOOKING_DATE DESC
        ">
        <SelectParameters>
            <asp:ControlParameter
                Name="USER_ID"
                ControlID="ddlUser"
                PropertyName="SelectedValue"
                Type="Decimal"
                ConvertEmptyStringToNull="True" />
        </SelectParameters>
    </asp:SqlDataSource>
</div>

</asp:Content>