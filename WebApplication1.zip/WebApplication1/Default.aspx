﻿<%@ Page Title="Home Page" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="WebApplication1._Default" %>
<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .dash-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 36px 40px;
        background: #f4f4f8;
        min-height: 100vh;
    }

    .dash-header {
        margin-bottom: 28px;
    }

    .dash-header h1 {
        font-size: 26px;
        font-weight: 700;
        color: #1a1a2e;
        margin: 0 0 4px 0;
    }

    .dash-header p {
        font-size: 13px;
        color: #999;
        margin: 0;
    }

    .cards-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 28px;
    }

    .card {
        border-radius: 10px;
        padding: 24px 20px;
        color: #fff;
        box-shadow: 0 3px 12px rgba(0,0,0,0.10);
        transition: transform 0.18s;
    }

    .card:hover { transform: translateY(-3px); }

    .card-1 { background: #e74c3c; }
    .card-2 { background: #27ae60; }
    .card-3 { background: #2980b9; }
    .card-4 { background: #e67e22; }

    .card-label {
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        opacity: 0.85;
        margin-bottom: 10px;
    }

    .card-value {
        font-size: 40px;
        font-weight: 700;
        line-height: 1;
    }

    .chart-box {
        background: #fff;
        border-radius: 10px;
        padding: 24px 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        max-width: 400px;
    }

    .chart-title {
        font-size: 14px;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 18px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eeeeee;
    }

    @media (max-width: 900px) {
        .cards-grid { grid-template-columns: repeat(2, 1fr); }
        .dash-wrapper { padding: 20px 16px; }
        .chart-box { max-width: 100%; }
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>

<div class="dash-wrapper">

    <div class="dash-header">
        <h1>Kumari Cinema Dashboard</h1>
        <p>Overview of movies, theaters, showtimes and ticket sales.</p>
    </div>

    <div class="cards-grid">
        <div class="card card-1">
            <div class="card-label">Total Movies</div>
            <div class="card-value"><asp:Label ID="lblMovies" runat="server" Text="0" /></div>
        </div>
        <div class="card card-2">
            <div class="card-label">Total Theaters</div>
            <div class="card-value"><asp:Label ID="lblTheaters" runat="server" Text="0" /></div>
        </div>
        <div class="card card-3">
            <div class="card-label">Total Showtimes</div>
            <div class="card-value"><asp:Label ID="lblShowtimes" runat="server" Text="0" /></div>
        </div>
        <div class="card card-4">
            <div class="card-label">Tickets Sold</div>
            <div class="card-value"><asp:Label ID="lblTickets" runat="server" Text="0" /></div>
        </div>
    </div>

    <div class="chart-box">
        <div class="chart-title">Showtimes by Session</div>
        <canvas id="pieChart" height="200"></canvas>
    </div>

</div>

<asp:HiddenField ID="hfPieLabels" runat="server" />
<asp:HiddenField ID="hfPieData"   runat="server" />

<script>
    var pieLabels = (document.getElementById('<%= hfPieLabels.ClientID %>').value || '').split('|').filter(Boolean);
    var pieValues = (document.getElementById('<%= hfPieData.ClientID %>').value || '').split('|').filter(Boolean).map(Number);

    if (pieLabels.length === 0) { pieLabels = ['DAY', 'EVENING', 'NIGHT']; pieValues = [1, 1, 1]; }

    new Chart(document.getElementById('pieChart'), {
        type: 'doughnut',
        data: {
            labels: pieLabels,
            datasets: [{
                data: pieValues,
                backgroundColor: ['#2980b9', '#e67e22', '#e74c3c'],
                borderWidth: 3,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom', labels: { padding: 14, font: { size: 12 } } },
                tooltip: { enabled: false }
            }
        }
    });
</script>

</asp:Content>
