﻿<%@ Page Title ="Movie Page" Language="C#" MasterPageFile="~/site.Master" AutoEventWireup="true" CodeBehind="Movie.aspx.cs" Inherits="WebApplication1.Movie" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .page-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .page-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .data-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .data-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .data-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
    }

    .data-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .data-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .data-grid tr:hover td { background-color: #f5f5fb; }

    .insert-form {
        background: #fff;
        border: 1px solid #e8e8e8;
        border-radius: 8px;
        padding: 24px 28px;
        margin-top: 32px;
        max-width: 500px;
    }

    .insert-form .form-title {
        font-size: 17px;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 18px;
    }

    .insert-form .field-label {
        display: block;
        font-weight: 600;
        font-size: 13px;
        color: #555;
        margin-top: 14px;
        margin-bottom: 5px;
    }

    .insert-form input[type=text] {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    .insert-form input[type=text]:focus {
        outline: none;
        border-color: #1a1a2e;
    }

    .btn-action {
        display: inline-block;
        margin-top: 18px;
        margin-right: 8px;
        padding: 9px 20px;
        background-color: #1a1a2e;
        color: #fff !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-action:hover { background-color: #2e2e5e; }

    .btn-cancel {
        display: inline-block;
        margin-top: 18px;
        padding: 9px 20px;
        background-color: #f0f0f0;
        color: #333 !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-cancel:hover { background-color: #e0e0e0; }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="page-wrapper">
    <h2>Movies</h2>

    <div class="data-grid">
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
            DataKeyNames="MOVIE_ID" DataSourceID="SqlDataSource1"
            BorderWidth="0" GridLines="None"
            EmptyDataText="No movies found."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="MOVIE_ID"     HeaderText="Movie ID"     ReadOnly="True" />
                <asp:BoundField DataField="TITLE"        HeaderText="Title" />
                <asp:BoundField DataField="DURATION"     HeaderText="Duration" />
                <asp:BoundField DataField="LANGUAGE"     HeaderText="Language" />
                <asp:BoundField DataField="GENRE"        HeaderText="Genre" />
                <asp:BoundField DataField="RELEASE_DATE" HeaderText="Release Date"
                                DataFormatString="{0:dd-MMM-yyyy}" />
                <asp:CommandField ShowDeleteButton="True" ShowEditButton="True" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource ID="SqlDataSource1" runat="server"
        ConnectionString="<%$ ConnectionStrings:Movie %>"
        ProviderName="<%$ ConnectionStrings:Movie.ProviderName %>"
        SelectCommand="SELECT * FROM &quot;MOVIE&quot;"
        DeleteCommand="DELETE FROM &quot;MOVIE&quot; WHERE &quot;MOVIE_ID&quot; = :MOVIE_ID"
        InsertCommand="INSERT INTO &quot;MOVIE&quot; (&quot;MOVIE_ID&quot;, &quot;TITLE&quot;, &quot;DURATION&quot;, &quot;LANGUAGE&quot;, &quot;GENRE&quot;, &quot;RELEASE_DATE&quot;) VALUES (:MOVIE_ID, :TITLE, :DURATION, :LANGUAGE, :GENRE, :RELEASE_DATE)"
        UpdateCommand="UPDATE &quot;MOVIE&quot; SET &quot;TITLE&quot; = :TITLE, &quot;DURATION&quot; = :DURATION, &quot;LANGUAGE&quot; = :LANGUAGE, &quot;GENRE&quot; = :GENRE, &quot;RELEASE_DATE&quot; = :RELEASE_DATE WHERE &quot;MOVIE_ID&quot; = :MOVIE_ID">
        <DeleteParameters><asp:Parameter Name="MOVIE_ID" Type="Decimal" /></DeleteParameters>
        <InsertParameters>
            <asp:Parameter Name="MOVIE_ID"     Type="Decimal" />
            <asp:Parameter Name="TITLE"        Type="String" />
            <asp:Parameter Name="DURATION"     Type="Decimal" />
            <asp:Parameter Name="LANGUAGE"     Type="String" />
            <asp:Parameter Name="GENRE"        Type="String" />
            <asp:Parameter Name="RELEASE_DATE" Type="DateTime" />
        </InsertParameters>
        <UpdateParameters>
            <asp:Parameter Name="TITLE"        Type="String" />
            <asp:Parameter Name="DURATION"     Type="Decimal" />
            <asp:Parameter Name="LANGUAGE"     Type="String" />
            <asp:Parameter Name="GENRE"        Type="String" />
            <asp:Parameter Name="RELEASE_DATE" Type="DateTime" />
            <asp:Parameter Name="MOVIE_ID"     Type="Decimal" />
        </UpdateParameters>
    </asp:SqlDataSource>

    <div class="insert-form">
        <div class="form-title">Add New Movie</div>
        <asp:FormView ID="FormView1" DefaultMode="Insert" runat="server"
            DataKeyNames="MOVIE_ID" DataSourceID="SqlDataSource2">
            <InsertItemTemplate>
                <span class="field-label">Movie ID</span>
                <asp:TextBox ID="MOVIE_IDTextBox"     runat="server" Text='<%# Bind("MOVIE_ID") %>' />
                <span class="field-label">Title</span>
                <asp:TextBox ID="TITLETextBox"        runat="server" Text='<%# Bind("TITLE") %>' />
                <span class="field-label">Duration</span>
                <asp:TextBox ID="DURATIONTextBox"     runat="server" Text='<%# Bind("DURATION") %>' />
                <span class="field-label">Language</span>
                <asp:TextBox ID="LANGUAGETextBox"     runat="server" Text='<%# Bind("LANGUAGE") %>' />
                <span class="field-label">Genre</span>
                <asp:TextBox ID="GENRETextBox"        runat="server" Text='<%# Bind("GENRE") %>' />
                <span class="field-label">Release Date</span>
                <asp:TextBox ID="RELEASE_DATETextBox" runat="server" Text='<%# Bind("RELEASE_DATE") %>' />
                <br />
                <asp:LinkButton ID="InsertButton"       runat="server" CausesValidation="True"  CommandName="Insert" Text="Insert" CssClass="btn-action" />
                <asp:LinkButton ID="InsertCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </InsertItemTemplate>
            <EditItemTemplate>
                <span class="field-label">Title</span>
                <asp:TextBox ID="TITLETextBox"        runat="server" Text='<%# Bind("TITLE") %>' />
                <span class="field-label">Duration</span>
                <asp:TextBox ID="DURATIONTextBox"     runat="server" Text='<%# Bind("DURATION") %>' />
                <span class="field-label">Language</span>
                <asp:TextBox ID="LANGUAGETextBox"     runat="server" Text='<%# Bind("LANGUAGE") %>' />
                <span class="field-label">Genre</span>
                <asp:TextBox ID="GENRETextBox"        runat="server" Text='<%# Bind("GENRE") %>' />
                <span class="field-label">Release Date</span>
                <asp:TextBox ID="RELEASE_DATETextBox" runat="server" Text='<%# Bind("RELEASE_DATE") %>' />
                <br />
                <asp:LinkButton ID="UpdateButton"       runat="server" CausesValidation="True"  CommandName="Update" Text="Update" CssClass="btn-action" />
                <asp:LinkButton ID="UpdateCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </EditItemTemplate>
            <ItemTemplate></ItemTemplate>
        </asp:FormView>
    </div>

    <asp:SqlDataSource ID="SqlDataSource2" runat="server"
        ConnectionString="<%$ ConnectionStrings:Movie %>"
        ProviderName="<%$ ConnectionStrings:Movie.ProviderName %>"
        SelectCommand="SELECT * FROM &quot;MOVIE&quot;"
        DeleteCommand="DELETE FROM &quot;MOVIE&quot; WHERE &quot;MOVIE_ID&quot; = :MOVIE_ID"
        InsertCommand="INSERT INTO &quot;MOVIE&quot; (&quot;MOVIE_ID&quot;, &quot;TITLE&quot;, &quot;DURATION&quot;, &quot;LANGUAGE&quot;, &quot;GENRE&quot;, &quot;RELEASE_DATE&quot;) VALUES (:MOVIE_ID, :TITLE, :DURATION, :LANGUAGE, :GENRE, :RELEASE_DATE)"
        UpdateCommand="UPDATE &quot;MOVIE&quot; SET &quot;TITLE&quot; = :TITLE, &quot;DURATION&quot; = :DURATION, &quot;LANGUAGE&quot; = :LANGUAGE, &quot;GENRE&quot; = :GENRE, &quot;RELEASE_DATE&quot; = :RELEASE_DATE WHERE &quot;MOVIE_ID&quot; = :MOVIE_ID">
        <DeleteParameters><asp:Parameter Name="MOVIE_ID" Type="Decimal" /></DeleteParameters>
        <InsertParameters>
            <asp:Parameter Name="MOVIE_ID"     Type="Decimal" />
            <asp:Parameter Name="TITLE"        Type="String" />
            <asp:Parameter Name="DURATION"     Type="Decimal" />
            <asp:Parameter Name="LANGUAGE"     Type="String" />
            <asp:Parameter Name="GENRE"        Type="String" />
            <asp:Parameter Name="RELEASE_DATE" Type="DateTime" />
        </InsertParameters>
        <UpdateParameters>
            <asp:Parameter Name="TITLE"        Type="String" />
            <asp:Parameter Name="DURATION"     Type="Decimal" />
            <asp:Parameter Name="LANGUAGE"     Type="String" />
            <asp:Parameter Name="GENRE"        Type="String" />
            <asp:Parameter Name="RELEASE_DATE" Type="DateTime" />
            <asp:Parameter Name="MOVIE_ID"     Type="Decimal" />
        </UpdateParameters>
    </asp:SqlDataSource>
</div>

</asp:Content>
