﻿<%@ Page Title ="Ticket Page" Language="C#" MasterPageFile="~/site.Master" AutoEventWireup="true" CodeBehind="Ticket.aspx.cs" Inherits="WebApplication1.Ticket" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

<style>
    .page-wrapper {
        font-family: 'Segoe UI', sans-serif;
        padding: 30px 40px;
    }

    .page-wrapper h2 {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 24px;
        color: #1a1a2e;
    }

    .data-grid table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        font-size: 14px;
    }

    .data-grid th {
        background-color: #1a1a2e;
        color: #fff;
        padding: 12px 20px;
        text-align: left;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .data-grid td {
        padding: 14px 20px;
        background-color: #fff;
        border-top: 1px solid #e8e8e8;
        border-bottom: 1px solid #e8e8e8;
        color: #333;
    }

    .data-grid td:first-child {
        border-left: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .data-grid td:last-child {
        border-right: 1px solid #e8e8e8;
        border-radius: 0 6px 6px 0;
    }

    .data-grid tr:hover td {
        background-color: #f5f5fb;
    }

    .insert-form {
        background: #fff;
        border: 1px solid #e8e8e8;
        border-radius: 8px;
        padding: 24px 28px;
        margin-top: 32px;
        max-width: 500px;
    }

    .insert-form .form-title {
        font-size: 17px;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 18px;
    }

    .insert-form .field-label {
        display: block;
        font-weight: 600;
        font-size: 13px;
        color: #555;
        margin-top: 14px;
        margin-bottom: 5px;
    }

    .insert-form input[type=text] {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    .insert-form input[type=text]:focus {
        outline: none;
        border-color: #1a1a2e;
    }

    .btn-action {
        display: inline-block;
        margin-top: 18px;
        margin-right: 8px;
        padding: 9px 20px;
        background-color: #1a1a2e;
        color: #fff !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-action:hover { background-color: #2e2e5e; }

    .btn-cancel {
        display: inline-block;
        margin-top: 18px;
        padding: 9px 20px;
        background-color: #f0f0f0;
        color: #333 !important;
        border-radius: 6px;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
    }

    .btn-cancel:hover { background-color: #e0e0e0; }

    .empty-msg {
        padding: 20px;
        color: #888;
        font-style: italic;
    }
</style>

<div class="page-wrapper">
    <h2>Tickets</h2>

    <div class="data-grid">
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False"
            DataKeyNames="TICKET_ID" DataSourceID="SqlDataSource1"
            BorderWidth="0" GridLines="None"
            EmptyDataText="No tickets found."
            EmptyDataRowStyle-CssClass="empty-msg">
            <Columns>
                <asp:BoundField DataField="TICKET_ID"      HeaderText="Ticket ID"      ReadOnly="True" />
                <asp:BoundField DataField="BOOKING_ID"     HeaderText="Booking ID" />
                <asp:BoundField DataField="SEAT_ID"        HeaderText="Seat ID" />
                <asp:BoundField DataField="TICKET_PRICE"   HeaderText="Price" />
                <asp:BoundField DataField="TICKET_STATUS"  HeaderText="Ticket Status" />
                <asp:BoundField DataField="PAYMENT_STATUS" HeaderText="Payment Status" />
                <asp:CommandField ShowDeleteButton="True" ShowEditButton="True" />
            </Columns>
        </asp:GridView>
    </div>

    <asp:SqlDataSource ID="SqlDataSource1" runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="SELECT * FROM &quot;TICKET&quot;"
        DeleteCommand="DELETE FROM &quot;TICKET&quot; WHERE &quot;TICKET_ID&quot; = :TICKET_ID"
        InsertCommand="INSERT INTO &quot;TICKET&quot; (&quot;TICKET_ID&quot;, &quot;BOOKING_ID&quot;, &quot;SEAT_ID&quot;, &quot;TICKET_PRICE&quot;, &quot;TICKET_STATUS&quot;, &quot;PAYMENT_STATUS&quot;) VALUES (:TICKET_ID, :BOOKING_ID, :SEAT_ID, :TICKET_PRICE, :TICKET_STATUS, :PAYMENT_STATUS)"
        UpdateCommand="UPDATE &quot;TICKET&quot; SET &quot;BOOKING_ID&quot; = :BOOKING_ID, &quot;SEAT_ID&quot; = :SEAT_ID, &quot;TICKET_PRICE&quot; = :TICKET_PRICE, &quot;TICKET_STATUS&quot; = :TICKET_STATUS, &quot;PAYMENT_STATUS&quot; = :PAYMENT_STATUS WHERE &quot;TICKET_ID&quot; = :TICKET_ID">
        <DeleteParameters><asp:Parameter Name="TICKET_ID" Type="Decimal" /></DeleteParameters>
        <InsertParameters>
            <asp:Parameter Name="TICKET_ID"      Type="Decimal" />
            <asp:Parameter Name="BOOKING_ID"     Type="Decimal" />
            <asp:Parameter Name="SEAT_ID"        Type="Decimal" />
            <asp:Parameter Name="TICKET_PRICE"   Type="Decimal" />
            <asp:Parameter Name="TICKET_STATUS"  Type="String" />
            <asp:Parameter Name="PAYMENT_STATUS" Type="String" />
        </InsertParameters>
        <UpdateParameters>
            <asp:Parameter Name="BOOKING_ID"     Type="Decimal" />
            <asp:Parameter Name="SEAT_ID"        Type="Decimal" />
            <asp:Parameter Name="TICKET_PRICE"   Type="Decimal" />
            <asp:Parameter Name="TICKET_STATUS"  Type="String" />
            <asp:Parameter Name="PAYMENT_STATUS" Type="String" />
            <asp:Parameter Name="TICKET_ID"      Type="Decimal" />
        </UpdateParameters>
    </asp:SqlDataSource>

    <div class="insert-form">
        <div class="form-title">Add New Ticket</div>
        <asp:FormView ID="FormView1" DefaultMode="Insert" runat="server"
            DataKeyNames="TICKET_ID" DataSourceID="SqlDataSource3"
            OnPageIndexChanging="FormView1_PageIndexChanging">
            <InsertItemTemplate>
                <span class="field-label">Ticket ID</span>
                <asp:TextBox ID="TICKET_IDTextBox"      runat="server" Text='<%# Bind("TICKET_ID") %>' />
                <span class="field-label">Booking ID</span>
                <asp:TextBox ID="BOOKING_IDTextBox"     runat="server" Text='<%# Bind("BOOKING_ID") %>' />
                <span class="field-label">Seat ID</span>
                <asp:TextBox ID="SEAT_IDTextBox"        runat="server" Text='<%# Bind("SEAT_ID") %>' />
                <span class="field-label">Ticket Price</span>
                <asp:TextBox ID="TICKET_PRICETextBox"   runat="server" Text='<%# Bind("TICKET_PRICE") %>' />
                <span class="field-label">Ticket Status</span>
                <asp:TextBox ID="TICKET_STATUSTextBox"  runat="server" Text='<%# Bind("TICKET_STATUS") %>' />
                <span class="field-label">Payment Status</span>
                <asp:TextBox ID="PAYMENT_STATUSTextBox" runat="server" Text='<%# Bind("PAYMENT_STATUS") %>' />
                <br />
                <asp:LinkButton ID="InsertButton"       runat="server" CausesValidation="True"  CommandName="Insert" Text="Insert" CssClass="btn-action" />
                <asp:LinkButton ID="InsertCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </InsertItemTemplate>
            <EditItemTemplate>
                <span class="field-label">Booking ID</span>
                <asp:TextBox ID="BOOKING_IDTextBox"     runat="server" Text='<%# Bind("BOOKING_ID") %>' />
                <span class="field-label">Seat ID</span>
                <asp:TextBox ID="SEAT_IDTextBox"        runat="server" Text='<%# Bind("SEAT_ID") %>' />
                <span class="field-label">Ticket Price</span>
                <asp:TextBox ID="TICKET_PRICETextBox"   runat="server" Text='<%# Bind("TICKET_PRICE") %>' />
                <span class="field-label">Ticket Status</span>
                <asp:TextBox ID="TICKET_STATUSTextBox"  runat="server" Text='<%# Bind("TICKET_STATUS") %>' />
                <span class="field-label">Payment Status</span>
                <asp:TextBox ID="PAYMENT_STATUSTextBox" runat="server" Text='<%# Bind("PAYMENT_STATUS") %>' />
                <br />
                <asp:LinkButton ID="UpdateButton"       runat="server" CausesValidation="True"  CommandName="Update" Text="Update" CssClass="btn-action" />
                <asp:LinkButton ID="UpdateCancelButton" runat="server" CausesValidation="False" CommandName="Cancel" Text="Cancel" CssClass="btn-cancel" />
            </EditItemTemplate>
            <ItemTemplate></ItemTemplate>
        </asp:FormView>
    </div>

    <asp:SqlDataSource ID="SqlDataSource3" runat="server"
        ConnectionString="<%$ ConnectionStrings:Ticket %>"
        ProviderName="<%$ ConnectionStrings:Ticket.ProviderName %>"
        SelectCommand="SELECT * FROM &quot;TICKET&quot;"
        DeleteCommand="DELETE FROM &quot;TICKET&quot; WHERE &quot;TICKET_ID&quot; = :TICKET_ID"
        InsertCommand="INSERT INTO &quot;TICKET&quot; (&quot;TICKET_ID&quot;, &quot;BOOKING_ID&quot;, &quot;SEAT_ID&quot;, &quot;TICKET_PRICE&quot;, &quot;TICKET_STATUS&quot;, &quot;PAYMENT_STATUS&quot;) VALUES (:TICKET_ID, :BOOKING_ID, :SEAT_ID, :TICKET_PRICE, :TICKET_STATUS, :PAYMENT_STATUS)"
        UpdateCommand="UPDATE &quot;TICKET&quot; SET &quot;BOOKING_ID&quot; = :BOOKING_ID, &quot;SEAT_ID&quot; = :SEAT_ID, &quot;TICKET_PRICE&quot; = :TICKET_PRICE, &quot;TICKET_STATUS&quot; = :TICKET_STATUS, &quot;PAYMENT_STATUS&quot; = :PAYMENT_STATUS WHERE &quot;TICKET_ID&quot; = :TICKET_ID">
        <DeleteParameters><asp:Parameter Name="TICKET_ID" Type="Decimal" /></DeleteParameters>
        <InsertParameters>
            <asp:Parameter Name="TICKET_ID"      Type="Decimal" />
            <asp:Parameter Name="BOOKING_ID"     Type="Decimal" />
            <asp:Parameter Name="SEAT_ID"        Type="Decimal" />
            <asp:Parameter Name="TICKET_PRICE"   Type="Decimal" />
            <asp:Parameter Name="TICKET_STATUS"  Type="String" />
            <asp:Parameter Name="PAYMENT_STATUS" Type="String" />
        </InsertParameters>
        <UpdateParameters>
            <asp:Parameter Name="BOOKING_ID"     Type="Decimal" />
            <asp:Parameter Name="SEAT_ID"        Type="Decimal" />
            <asp:Parameter Name="TICKET_PRICE"   Type="Decimal" />
            <asp:Parameter Name="TICKET_STATUS"  Type="String" />
            <asp:Parameter Name="PAYMENT_STATUS" Type="String" />
            <asp:Parameter Name="TICKET_ID"      Type="Decimal" />
        </UpdateParameters>
    </asp:SqlDataSource>
</div>

</asp:Content>
