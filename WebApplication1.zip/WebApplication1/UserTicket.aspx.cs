﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class UserTicket : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Clear to prevent duplicates on first load
                ddlUser.Items.Clear();
            }
        }
    }
}