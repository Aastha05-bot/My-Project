using MyDiary.Models;

namespace MyDiary.Services
{
    public class StreakService
    {
        public (int current, int longest, int missed) CalculateStreak(List<JournalEntry> journals)
        {
            if (journals == null || !journals.Any())
                return (0, 0, 0);

            var dates = journals
                .Select(j => j.EntryDate.Date)
                .Distinct()
                .OrderBy(d => d)
                .ToList();

            DateTime today = DateTime.Today;

            // --------------------
            // CURRENT STREAK
            // --------------------
            int currentStreak = 0;
            DateTime checkDate = today;

            while (dates.Contains(checkDate))
            {
                currentStreak++;
                checkDate = checkDate.AddDays(-1);
            }

            // --------------------
            // LONGEST STREAK
            // --------------------
            int longestStreak = 1;
            int temp = 1;

            for (int i = 1; i < dates.Count; i++)
            {
                if ((dates[i] - dates[i - 1]).Days == 1)
                {
                    temp++;
                    longestStreak = Math.Max(longestStreak, temp);
                }
                else
                {
                    temp = 1;
                }
            }

            // --------------------
            // MISSED DAYS
            // --------------------
            int missedDays = Math.Max(0, (today - dates.Last()).Days - 1);

            return (currentStreak, longestStreak, missedDays);
        }
    }
}
