using MyDiary.Models;

namespace MyDiary.Services;

public class SearchFilterService
{
    public List<JournalEntry> Filter(
        List<JournalEntry> entries,
        string? searchTerm,
        string? mood,
        string? tag,
        DateTime? fromDate,
        DateTime? toDate
    )
    {
        if (entries == null || !entries.Any())
            return new();

        IEnumerable<JournalEntry> query = entries;

        // 🔍 SEARCH (title, content, tags, moods)
        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            var term = searchTerm.ToLower();

            query = query.Where(j =>
                (!string.IsNullOrWhiteSpace(j.Title) &&
                    j.Title.ToLower().Contains(term)) ||

                (!string.IsNullOrWhiteSpace(j.Content) &&
                    j.Content.ToLower().Contains(term)) ||

                (!string.IsNullOrWhiteSpace(j.Tags) &&
                    j.Tags.ToLower().Contains(term)) ||

                (!string.IsNullOrWhiteSpace(j.PrimaryMood) &&
                    j.PrimaryMood.ToLower().Contains(term)) ||

                (!string.IsNullOrWhiteSpace(j.SecondaryMoods) &&
                    j.SecondaryMoods.ToLower().Contains(term))
            );
        }

        // 🎭 FILTER BY MOOD (PRIMARY + SECONDARY)
        if (!string.IsNullOrWhiteSpace(mood))
        {
            query = query.Where(j =>
                j.PrimaryMood == mood ||
                (!string.IsNullOrWhiteSpace(j.SecondaryMoods) &&
                    j.SecondaryMoods.Split(',').Contains(mood))
            );
        }

        // 🏷 FILTER BY TAG
        if (!string.IsNullOrWhiteSpace(tag))
        {
            query = query.Where(j =>
                !string.IsNullOrWhiteSpace(j.Tags) &&
                j.Tags.Split(',').Any(t => t.Trim() == tag)
            );
        }

        // 📅 FILTER BY DATE RANGE
        if (fromDate.HasValue)
            query = query.Where(j => j.EntryDate.Date >= fromDate.Value.Date);

        if (toDate.HasValue)
            query = query.Where(j => j.EntryDate.Date <= toDate.Value.Date);

        return query
            .OrderByDescending(j => j.EntryDate)
            .ToList();
    }
}
