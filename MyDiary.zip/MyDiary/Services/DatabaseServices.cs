using SQLite;
using MyDiary.Models;
using System.Text.Json;

namespace MyDiary.Services;

public class DatabaseService
{
    public SQLiteAsyncConnection Db { get; }

    public DatabaseService()
    {
        var path = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "mydiary.db");

        Db = new SQLiteAsyncConnection(path);
    }

    // ✅ CALL THIS ON APP START
    public async Task InitializeAsync()
    {
        await Db.CreateTableAsync<JournalEntry>();
        await Db.CreateTableAsync<Tag>();
    }

    // ========================
    // JOURNAL
    // ========================
    public async Task<List<JournalEntry>> GetAllAsync()
        => await Db.Table<JournalEntry>()
                   .OrderByDescending(j => j.EntryDate)
                   .ToListAsync();

    public async Task<JournalEntry?> GetByDateAsync(DateTime date)
        => await Db.Table<JournalEntry>()
                   .Where(j => j.EntryDate.Date == date.Date)
                   .FirstOrDefaultAsync();

    public async Task SaveAsync(JournalEntry entry)
    {
        entry.UpdatedAt = DateTime.Now;

        if (entry.Id == 0)
        {
            entry.CreatedAt = DateTime.Now;
            await Db.InsertAsync(entry);
        }
        else
        {
            await Db.UpdateAsync(entry);
        }

        // 🔥 Track tag usage
        await UpdateTagUsage(entry.Tags);
    }

    public async Task DeleteAsync(DateTime date)
    {
        var entry = await GetByDateAsync(date);
        if (entry != null)
            await Db.DeleteAsync(entry);
    }

    // ========================
    // TAGS
    // ========================
    public async Task<List<Tag>> GetAllTagsAsync()
        => await Db.Table<Tag>()
                   .OrderByDescending(t => t.UseCount)
                   .ThenBy(t => t.Name)
                   .ToListAsync();

    private async Task UpdateTagUsage(string tagJson)
    {
        if (string.IsNullOrWhiteSpace(tagJson)) return;

        List<string> tags;

        try
        {
            tags = JsonSerializer.Deserialize<List<string>>(tagJson) ?? new();
        }
        catch
        {
            return;
        }

        foreach (var raw in tags)
        {
            // ✅ Normalize tag
            var name = raw
                .Trim()
                .TrimStart('#')
                .ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(name))
                continue;

            var existing = await Db.Table<Tag>()
                .Where(t => t.Name == name)
                .FirstOrDefaultAsync();

            if (existing == null)
            {
                await Db.InsertAsync(new Tag
                {
                    Name = name,
                    UseCount = 1,
                    CreatedAt = DateTime.Now
                });
            }
            else
            {
                existing.UseCount++;
                await Db.UpdateAsync(existing);
            }
        }
    }
}
