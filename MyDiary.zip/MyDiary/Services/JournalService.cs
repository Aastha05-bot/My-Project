using MyDiary.Models;
using SQLite;

namespace MyDiary.Services;

public class JournalService
{
    private readonly SQLiteAsyncConnection _db;

    public JournalService()
    {
        var dbPath = Path.Combine(
            FileSystem.AppDataDirectory,
            "journal.db");

        _db = new SQLiteAsyncConnection(dbPath);

        _db.CreateTableAsync<JournalEntry>().Wait();
    }

    // CREATE or UPDATE
    public async Task SaveAsync(JournalEntry entry)
    {
        var existing = await GetByDateAsync(entry.EntryDate);

        entry.UpdatedAt = DateTime.Now;

        if (existing == null)
        {
            entry.CreatedAt = DateTime.Now;
            await _db.InsertAsync(entry);
        }
        else
        {
            entry.Id = existing.Id;
            await _db.UpdateAsync(entry);
        }
    }

    // READ (all)
    public async Task<List<JournalEntry>> GetAllAsync()
    {
        return await _db
            .Table<JournalEntry>()
            .OrderByDescending(e => e.EntryDate)
            .ToListAsync();
    }

    // READ (by date)
    public async Task<JournalEntry?> GetByDateAsync(DateTime date)
    {
        return await _db
            .Table<JournalEntry>()
            .FirstOrDefaultAsync(e => e.EntryDate == date.Date);
    }

    // ✅ DELETE (THIS FIXES YOUR ERROR)
    public async Task DeleteAsync(DateTime date)
    {
        var entry = await GetByDateAsync(date);
        if (entry != null)
        {
            await _db.DeleteAsync(entry);
        }
    }
}