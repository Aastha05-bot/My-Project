﻿using Microsoft.Extensions.Logging;
using MyDiary.Services;

namespace MyDiary;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();

        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });

        // 🔹 MAUI Blazor
        builder.Services.AddMauiBlazorWebView();

        // 🔹 REGISTER APPLICATION SERVICES (VERY IMPORTANT)
        builder.Services.AddSingleton<JournalService>();
        builder.Services.AddSingleton<DatabaseService>();
		builder.Services.AddSingleton<ThemeService>();
        builder.Services.AddSingleton<StreakService>();
        builder.Services.AddSingleton<SearchFilterService>();


#if DEBUG
        builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}
