using SQLite;

namespace MyDiary.Models;

public class JournalEntry
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    // ONE entry per day
    [Indexed(Unique = true)]
    public DateTime EntryDate { get; set; }

    public string Title { get; set; } = "";
    public string Content { get; set; } = "";

    // Mood system
    public string PrimaryMood { get; set; } = "";        // Required
    public string SecondaryMoods { get; set; } = "";     // Max 2, comma-separated
    public string MoodCategory { get; set; } = "";       // Positive / Neutral / Negative

    // Organization
    public string Category { get; set; } = "";           // One category
    public string Tags { get; set; } = "";               // Predefined + custom

    // System timestamps
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}