using SQLite;

namespace MyDiary.Models
{
    public class Tag
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        // Tag name WITHOUT #
        [Unique]
        public string Name { get; set; } = "";

        // How many times this tag was used
        public int UseCount { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
