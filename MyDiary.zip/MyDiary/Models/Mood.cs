using SQLite;

namespace MyDiary.Models
{
    public class Mood
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        // e.g. Happy, Sad, Calm
        [Indexed]
        public string Name { get; set; } = "";

        // Positive / Neutral / Negative
        public string Category { get; set; } = "";

        // Analytics support
        public int UseCount { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
